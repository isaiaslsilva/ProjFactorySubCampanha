package br.com.modelo;

import br.com.generico.CriadorCampanha;

public class CriadorVendaResidencial implements CriadorCampanha {

	@Override
	public void criar(String nome) {
		System.out.println(nome);
	}
}
