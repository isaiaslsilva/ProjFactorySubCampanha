package br.com.generico;

public enum SubCampanha {
	VendasCorporativa, VendaResidencial;
}
