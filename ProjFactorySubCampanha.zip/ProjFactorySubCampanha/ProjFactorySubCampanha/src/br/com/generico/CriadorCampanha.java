package br.com.generico;

public interface CriadorCampanha {

	public void criar(String nome);
	
	
}
