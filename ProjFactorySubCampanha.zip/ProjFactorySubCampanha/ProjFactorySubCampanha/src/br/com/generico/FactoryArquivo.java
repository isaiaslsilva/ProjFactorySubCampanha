package br.com.generico;

import br.com.modelo.CriadorVendasCorporativa;
import br.com.modelo.CriadorVendaResidencial;

public class FactoryArquivo {

	public static CriadorCampanha criador(String subcampanha) {
		if (subcampanha.equals("VendasCorporativa")) {
			return new CriadorVendasCorporativa();
		} 
		else {
			return new CriadorVendaResidencial();
		}
	}
	
}
