package br.com.main;

import br.com.generico.CriadorCampanha;
import br.com.generico.FactoryArquivo;
//import br.com.generico.SubCampanha;

public class MainFactory {


	public static void main(String[] args) {
		
String subcampanha = "VendasCorporativa" ;

CriadorCampanha criadorvendasresidencial = FactoryArquivo.criador(subcampanha);
criadorvendasresidencial.criar("VendaResidencial");


CriadorCampanha criadorvendascorporativa = FactoryArquivo.criador(subcampanha);
criadorvendascorporativa.criar("VendasCorporativa");


	}

}
